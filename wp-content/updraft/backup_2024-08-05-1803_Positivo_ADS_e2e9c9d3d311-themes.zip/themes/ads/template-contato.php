<?php
/* Template Name: Contato */ 
    get_header(); 
?>

<?php 
    get_footer(); 
?>
